#include <stdio.h>
#include <string.h>

int main(int argc, const char * argv[]) {
    //FILE* fr = fopen("/Users/jiharu/Desktop/2016-10-korean.html", "rt");
    //FILE* fw = fopen("/Users/jiharu/Desktop/2016-10-koreanW.html", "wt");
    FILE* fr = fopen(argv[1], "rt");
    FILE* fw = fopen(argv[2], "wt");
    char *match;
    char str[1000000];
    char dummy= '\0';
    int count = 0;
    while(!feof(fr)){
        if(str[count-1] == '>'){
            match = strstr(str,"div class=\"r\"");
            if(match != NULL){
                fscanf(fr, "%c", &str[count]);
                count++;
                str[count] = '\0';
                while(dummy != '>'){
                    fscanf(fr, "%c", &dummy);
                }
                dummy='\0';
            }
            else{
                fprintf(fw,"%s",str);
            }
            count = 0;
            str[count] = '\0';
        }
        else{
            fscanf(fr, "%c", &str[count]);
            count++;
            str[count] = '\0';
        }
    }
    return 0;
}
